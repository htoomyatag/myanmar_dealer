# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)


products = Product.create([

{title:"tmp",price: "10"},


])


bath_supply = BathSupply.create([

   # {title: "aokshampoo",
   # category: "bath_supplies",
   # ingredient: "livers",
   # usage: "one times a week",
   # made_by_country: "japan",
   # description: "dandruff shampoo",
   # brand: "pentine",
   # effect: "clean dandruff",
   # certification: "3453vgergrecerti",
   # age_group: "12 to 60",
   # price: "70000",
   # user_id: "1",
   # store_name: "H&Ttechs"}

])


beauty_equipments = BeautyEquipment.create([

   # {title:"temptitle",
   #  category:"beauty_equipments",
   #  brand:"tempbrand",
   #  made_by_country:"China",
   # description:"This is Descritpion",
   #  feature:"This is feature",
   #  modal_number:"tempmodal",
   #  color:"Red Green Blue",
   #  price:"500",
   #  user_id:"1",
   #  quantity:22,
   #  store_name:"H&Ttechs"}

    ])


  

       car_accessories = CarAccessory.create([

   # {title:"temptitle",
   #  price:"1000",
   #  quantity:"30",
   #  size:"tempsize",
   #  weight:"tempweight",
   #  made_by_country:"China",
   #  made_with:"tempmadewith",
   # description:"This is Descritpion",
   #  brand:"tempbrand",
   # specification:"this is specfication",
   #  modal_number:"tempmodal",
   #  color:"Red Green Blue",
   #  feature:"This is feature",
   #  category:"car_accessories",
   #  user_id:"1",
   #  store_name:"H&Ttechs"}

    ])


  

      computers = Computer.create([

   # {title:"temptitle",
   #  price:"1500",
   #  quantity:"30",
   #  size:"tempsize",
   #  weight:"tempweight",
   #  thickness:"tempticknesss",
   #  made_by_country:"China",
   # description:"This is Descritpion",
   #  brand:"tempbrand",
   #  category:"computers_laptops",
   #  modal_number:"tempmodal",
   #  color:"Red Green Blue",
   #  feature:"This is feature",
   #  operation_system:"android os",
   #  user_id:"1",
   #  store_name:"H&Ttechs"}

    ])


  
     electrical_equipments = ElectricalEquipment.create([

   # {title:"temptitle",
   #  price:"2000",
   #  quantity:"30",
   #  size:"tempsize",
   #  weight:"tempweight",
   #  made_by_country:"China",
   # description:"This is Descritpion",
   #  brand:"tempbrand",
   #  category:"eletronic_related",
   #  modal_number:"tempmodal",
   #  color:"Red Green Blue",
   #  user_id:"1",
   #  store_name:"H&Ttechs"}

    ])


  
      equipments = Equipment.create([

   # {title:"temptitle",
   #  price:"2500",
   #  quantity:"30",
   #  size:"tempsize",
   #  weight:"tempweight",
   #  made_by_country:"China",
   #  category:"equipments",
   #  made_with:"tempmadewith",
   # description:"This is Descritpion",
   #  brand:"tempbrand",
   # specification:"this is specfication",
   #  modal_number:"tempmodal",
   #  color:"Red Green Blue",
   #  user_id:"1",
   #  store_name:"H&Ttechs"}

    ])


  

    fashion_accessories = FashionAccessory.create([

   # {title:"temptitle",
   #  price:"3000",
   #  quantity:"30",
   #  made_by_country:"China",
   #  made_with:"tempmadewith",
   # description:"This is Descritpion",
   #  brand:"tempbrand",
   #  user_id:"1",
   #  category:"fashion_related",
   #  store_name:"H&Ttechs"}

    ])


  

fashion_bags = FashionBag.create([

          {
            title:"Luggage",
            price:19000,
            bag_type:"Luggage",
                        made_by_country: "China",
            size:"12 inches",
            category:"bags",
            store_name:"Luggage",
            color: "Deep Pink, Light pink, yellow, blue,green",
            user_id:"6"
          },


          {
            title:"Luggage",
            price:36000,
            bag_type:"Luggage",
                        made_by_country: "China",
            size:"20 inches",
            category:"bags",
            store_name:"Luggage",
            color: "Deep Pink, Light pink, yellow, blue,green",
            user_id:"6"
          },


              {
            title:"Luggage",
            price:40000,
            bag_type:"Luggage",
                        made_by_country: "China",
            size:"22 inches",
            category:"bags",
            store_name:"Luggage",
            color: "Deep Pink, Light pink, yellow, blue,green",
            user_id:"6"
          },


          {
            title:"Luggage",
            price:43000,
                        made_by_country: "China",
            bag_type:"Luggage",
            size:"24 inches",
            category:"bags",
            store_name:"Luggage",
            color: "Deep Pink, Light pink, yellow, blue,green",
            user_id:"6"
          },



          {
            title:"Luggage",
                        made_by_country: "China",
            price:44000,
            bag_type:"Luggage",
            size:"20 inches",
            category:"bags",
            store_name:"Luggage",
            color: "Art,Owl,cartoon,pink cow, yellow cow, blue cow",
            user_id:"6"
          },

          {
            title:"Luggage",
                        made_by_country: "China",
            price:51000,
            bag_type:"Luggage",
            size:"24 inches",
            category:"bags",
            store_name:"Luggage",
            color: "Art,Owl,cartoon,pink cow, yellow cow, blue cow",
            user_id:"6"
          },


          {
            title:"Luggage",
                        made_by_country: "China",
            price:35000,
            bag_type:"Luggage",
            size:"20 inches  ",
            category:"bags",
            store_name:"Luggage",
            color: "Light&DeepPink,Green,Yellow,Purple,Lightblue",
            user_id:"6"
          },

          {
            title:"Luggage",
                        made_by_country: "China",
            price:42000,
            bag_type:"Luggage",
            size:"24 inches  ",
            category:"bags",
            store_name:"Luggage",
            color: "Light&DeepPink,Green,Yellow,Purple,Lightblue",
            user_id:"6"
          }

    ])


  
    


  

      fashion_footwears = FashionFootwear.create([

          {
            title:"Shoes",
                        made_by_country: "China",
            price:"16000",
            footwear_type:"Shoes",
            size:"35,36,37,38,39",
            user_id:"5",
            color: "Black, Silver",
            category:"footwears",
            store_name:"Lady's foot wear"
          },


          {
            title:"Shoes",
                        made_by_country: "China",
            price:"16500",
            footwear_type:"Shoes",
            size:"35,36,37,38,39,40",
            user_id:"5",
            color: "Pink,Green",
            category:"footwears",
            store_name:"Lady's foot wear"
          },


          {
            title:"Shoes",
            price:"16500",
                        made_by_country: "China",
            footwear_type:"Shoes",
            size:"35,36,37,38,39,40",
            user_id:"5",
            color: "White,Red,Green",
            category:"footwears",
            store_name:"Lady's foot wear"
          },


          {
            title:"Shoes",
            price:"16500",
                        made_by_country: "China",
            footwear_type:"Shoes",
            size:"35,36,37,38,39",
            user_id:"5",
            color: "Black, Pink",
            category:"footwears",
            store_name:"Lady's foot wear"
          },



          {
            title:"Shoes",
            price:"16500",
                        made_by_country: "China",
            footwear_type:"Shoes",
            size:"35,36,37,38,39",
            user_id:"5",
            color: "Black,Red,Blue",
            category:"footwears",
            store_name:"Lady's foot wear"
          },


          {
            title:"Shoes",
            price:"17000",
                        made_by_country: "China",
            footwear_type:"Shoes",
            size:"35,36,37,38,39",
            user_id:"5",
            color: "Peaige,Grey,Black",
            category:"footwears",
            store_name:"Lady's foot wear"
          },


          {
            title:"Shoes",
            price:"14500",
             made_by_country: "China",
            footwear_type:"Shoes",
            size:"35,36,37,38,39",
            user_id:"5",
            color: "Rainbow",
            category:"footwears",
            store_name:"Lady's foot wear"
          },

          {
            title:"Shoes",
            price:"16500",
           made_by_country: "China",
            footwear_type:"Shoes",
            size:"35,36,37,38,39,40",
            user_id:"5",
            color: "Grey,Black",
            category:"footwears",
            store_name:"Lady's foot wear"
          },


          {
            title:"Shoes",
            price:"16500",
           made_by_country: "China",
            footwear_type:"Shoes",
            size:"35,36,37,38,39",
            user_id:"5",
            color: "White, Pink, Pink, Coffee",
            category:"footwears",
            store_name:"Lady's foot wear"
          },


          {
            title:"Shoes",
            price:"16500",
            made_by_country: "China",
            footwear_type:"Shoes",
            size:"35,36,37,38,39",
            user_id:"5",
            color: "White,Black",
            category:"footwears",
            store_name:"Lady's foot wear"
          },


          {
            title:"Shoes",
           made_by_country: "China",
            price:"16000",
            footwear_type:"Shoes",
            size:"35,36,37,38,39",
            user_id:"5",
            color: "White,Black",
            category:"footwears",
            store_name:"Lady's foot wear"
          },


          {
            title:"Shoes",
            made_by_country: "China",
            price:"15500",
            footwear_type:"Shoes",
            size:"35,36,37,38,39",
            user_id:"5",
            color: "Black,White",
            category:"footwears",
            store_name:"Lady's foot wear"
          },


          {
            title:"Sandal",
            made_by_country: "China",
            price:"19000",
            footwear_type:"Sandal",
            size:"35,36,37,38,39",
            user_id:"5",
            color: "Black,Grey",
            category:"footwears",
            store_name:"Lady's foot wear"
          },


          {
            title:"Sandal",
           made_by_country: "China",
            price:"19000",
            footwear_type:"Sandal",
            size:"35,36,37,38,39",
            user_id:"5",
            color: "Black",
            category:"footwears",
            store_name:"Lady's foot wear"
          },


         {
            title:"Sandal",
            made_by_country: "China",
            price:"16500",
            footwear_type:"Sandal",
            size:"35,36,37,38,39",
            user_id:"5",
            color: "Black",
            category:"footwears",
            store_name:"Lady's foot wear"
          },


         {
            title:"Sandal",
            made_by_country: "China",
            price:"23000",
            footwear_type:"Sandal",
            size:"35,36,37,38,39",
            user_id:"5",
            color: "Black,Kahki",
            category:"footwears",
            store_name:"Lady's foot wear"
          },



         {
            title:"Sandal",
            made_by_country: "China",
            price:"15500",
            footwear_type:"Sandal",
            size:"35,36,37,38,39",
            user_id:"5",
            color: "Black,White",
            category:"footwears",
            store_name:"Lady's foot wear"
          },


         {
            title:"Sandal",
            made_by_country: "China",
            price:"16500",
            footwear_type:"Sandal",
            size:"35,36,37,38,39",
            user_id:"5",
            color: "Black,Green",
            category:"footwears",
            store_name:"Lady's foot wear"
          },

         {
            title:"Sandal",
             made_by_country: "China",
            price:"16500",
            footwear_type:"Sandal",
            size:"35,36,37,38,39",
            user_id:"5",
            color: "Black ,Green,Pink",
            category:"footwears",
            store_name:"Lady's foot wear"
          },


          {
            title:"Sandal",
             made_by_country: "China",
            price:"18500",
            footwear_type:"Sandal",
            size:"35,36,37,38,39",
            user_id:"5",
            color: "Black,Kahki",
            category:"footwears",
            store_name:"Lady's foot wear"
          },


          {
            title:"Sandal",
             made_by_country: "China",
            price:"17000",
            footwear_type:"Sandal",
            size:"35,36,37,38,39",
            user_id:"5",
            color: "Black,Coffee",
            category:"footwears",
            store_name:"Lady's foot wear"
          },


          {
            title:"Lady Shoes",
            made_by_country: "China",
            price:"16000",
            footwear_type:"Lady Shoes",
            size:"35,36,37,38,39",
            user_id:"5",
            color: "Black,Red",
            category:"footwears",
            store_name:"Lady's foot wear"
          }

    ])


  

      fashion_hats = FashionHat.create([

        {title:"batman snapback",
        price:"9000 Kyats",
        made_by_country:"Thailand",
        hat_type:"snapback",
        user_id:"4",
        category:"hats",
        store_name:"S3 fashion"}

    ])


gifts = Gift.create([

   #  {title:"temptitle",
   #  price:"9000",
   #  quantity:"30",
   #  weight:"tempweight",
   #  made_by_country:"China",
   #  made_with:"tempmadewith",
   # description:"This is Descritpion",
   #  color:"Red Green Blue",
   #  user_id:"1",
   #  category:"gifts",
   #  store_name:"H&Ttechs"}

    ])


  

    home_appliances = HomeAppliance.create([

   #  {title:"temptitle",
   #  price:"8000",
   #  quantity:"30",
   #  size:"tempsize",
   #  weight:"tempweight",
   #  made_by_country:"China",
   # description:"This is Descritpion",
   #  brand:"tempbrand",
   #  modal_number:"tempmodal",
   #  color:"Red Green Blue",
   # feature:"This is feature",
   #  power:"14k",
   #  voltage:"22V",
   #  user_id:"1",
   #  category:"home_appliance",
   #  store_name:"H&Ttechs"}

    ])



  

instruments = Instrument.create([

   #  {title:"temptitle",
   #  price:"7000",
   #  quantity:"30",
   #  dimension:"12 x 40 fts",
   #  weight:"tempweight",
   #  made_by_country:"China",
   #  made_with:"tempmadewith",
   # description:"This is Descritpion",
   #  brand:"tempbrand",
   #  modal_number:"tempmodal",
   # specification:"this is specfication",
   #  color:"Red Green Blue",
   #  user_id:"1",
   #  category:"instruments",
   #  store_name:"H&Ttechs"}

    ])


    machines = Machine.create([

    # {title:"temptitle",
    # price:"900",
    # quantity:"30",
    # dimension:"12x41 fts",
    # weight:"tempweight",
    # made_by_country:"China",
    # made_with:"tempmadewith",
    # description:"This is Descritpion",
    # brand:"tempbrand",
    # modal_number:"tempmodal",
    # specification:"this is specfication",
    # color:"Red Green Blue",
    # category:"machines",
    # user_id:"1",
    # store_name:"H&Ttechs"}

    ])

  

  makeup_and_skincares = MakeupAndSkincare.create([

    # {title:"temptitle",
    #  category:"comesmetics",
    #  quantity:22,
    #  certification:"this is certification",
    #  ingredient:"thisisingredient",
    #  usage:"thissuage",
    #  made_by_country:"China",
    #  description:"This is Descritpion",
    #  brand:"tempbrand",
    #  color:"Red Green Blue",
    #  effect:"thisiseffect",
    #  price:"6000",
    #  user_id:"1",
    #  store_name:"H&Ttechs"}

    ])


  
medicines = Medicine.create([

    # {title:"temptitle",
    #  category:"medicines",
    #  certification:"thisiscerti",
    #  quantity:22,
    #  ingredient:"thisisingredient",
    #  usage:"thisisusage",
    #  made_by_country:"China",
    #  description:"This is Descritpion",
    #  caution:"thiscaution",
    #  price:"2000",
    #  user_id:"1",
    #  store_name:"H&Ttechs"}

    ])

  

 motorcycle_accessories = MotorcycleAccessory.create([

    # {title:"temptitle",
    # price:"8000",
    # quantity:"30",
    # size:"tempsize",
    # weight:"tempweight",
    # made_by_country:"China",
    # made_with:"tempmadewith",
    # description:"This is Descritpion",
    # brand:"tempbrand",
    # specification:"this is specfication",
    # modal_number:"tempmodal",
    # color:"Red Green Blue",
    # feature:"This is feature",
    # user_id:"1",
    # category:"motorcycle",
    # store_name:"H&Ttechs"}

    ])


  
services = Service.create([

  
   #  {title:"temptitle",
   #  charges:"thisischarges",
   #  service_category:"tempcategory",
   # description:"This is Descritpion",
   #  user_id:"1",
   #  store_name:"H&Ttechs"}

    ])
  

 sports = Sport.create([


   #  {title:"temptitle",
   #  price:"950",
   #  quantity:"30",
   #  weight:"tempweight",
   #  made_by_country:"China",
   #  made_with:"tempmadewith",
   # description:"This is Descritpion",
   #  color:"Red Green Blue",
   #  brand:"tempbrand",
   #  category:"sports",
   #  user_id:"1",
   #  store_name:"H&Ttechs"}

    ])


  


   telephone_accessories = TelephoneAccessory.create([


   #  {title:"temptitle",
   #  price:"300",
   #  quantity:"30",
   #  size:"tempsize",
   #  weight:"tempweight",
   #  made_by_country:"China",
   # description:"This is Descritpion",
   #  brand:"tempbrand",
   #  category:"phone_related",
   #  modal_number:"tempmodal",
   #  color:"Red Green Blue",
   # feature:"This is feature",
   #  operation_system:"android os",
   #  user_id:"1",
   #  store_name:"H&Ttechs"}

    ])


  
  toys = Toy.create([

    # {title:"temptitle",
    # price:"8000",
    # quantity:"30",
    # weight:"tempweight",
    # made_by_country:"China",
    # made_with:"tempmadewith",
    # description:"This is Descritpion",
    # color:"Red Green Blue",
    # age_group:"Adult 18 to 60",
    # user_id:"1",
    # category:"toys",
    # store_name:"H&Ttechs"}

    ])


  
  training_and_schools = TrainingAndSchool.create([


    # {title:"temptitle",
    # fees:"760",
    # period:"12July2016 to 12Dec2016",
    # school:"TTC",
    # description:"This is Descritpion",
    # user_id:"1",
    # store_name:"H&Ttechs"}

    ])



  







user_types = UserType.create([

{title:"Seller"},
{title:"Buyer"}

])



fashion_clothings = FashionClothing.create([



  {

    user_id:"4",
    title:"batman t-shirt",
    made_by_country: "Myanmar",
    price:10000,
    size:"S,M,L,XL",
    color: "White, Black",
    category: "cloths",
    store_name: "S3 fashion"

    },

  {

    user_id:"4",
    title:"Bull Dog",
    made_by_country: "Thailand",
    price: 7500,
    size:"S,M,L,XL",
    color: "White, Black",
    category: "cloths",
    store_name: "S3 fashion",
    brand: "Overdoze"

    },

     


      {

    user_id:"4",
    title:"BDVDS",
    made_by_country: "Thailand",
    price: 7500,
    size:"S,M,L,XL",
    color: "White, Black",
    category: "cloths",
    store_name: "S3 fashion",
    brand: "Overdoze"

    },

    {

    user_id:"1",
    title:"Plain Tee",
    made_by_country: "Thailand",
    price: 7500,
    size:"S,M,L,XL",
    color: "White, Black, Grey, LightGray",
    category: "cloths",
    store_name: "S3 fashion",
    brand: "Indi"

    },

    {

    user_id:"7",title:"Brassiere",
                made_by_country: "China",
    price:10000,
    size:"70/A32, 70B/32, 75/34A, 75/34B, 36/80A, 36/80B",
    color: "Black, Pearl, Red, Green, Pink, Grey, Peach",
    category: "cloths",
    store_name: "Lady's under wear"

    },


    {

    user_id:"7",
    title:"Brassiere (one set)",
                made_by_country: "China",
    price:13000,
    size:"70/A32, 70B/32, 75/34A, 75/34B, 36/80A, 36/80B",
    color: "Black, Pearl, Red, Green, Pink, Grey, Peach",
    category: "cloths",
    store_name: "Lady's under wear"

    },


    {

    user_id:"7",
    title:"Brassiere (one set)",
                made_by_country: "China",
    price:14000,
    size:"70/A32, 70B/32, 75/34A, 75/34B, 36/80A, 36/80B",
    color: "Flower",
    category: "cloths",
    store_name: "Lady's under wear"

    },



    {

    user_id:"7",
    title:"Brassiere (one set)",
                made_by_country: "China",
    price:16000,
    size:"70/32B, 75/34B, 36/80B",
    color: "Black, Pink, Corlourful",
    category: "cloths",
    store_name: "Lady's under wear"
    },



    {

    user_id:"7",
    title:"Brassiere",
                made_by_country: "China",
    price:14000,
    size:"70/32B, 75/34B, 36/80B",
    color: "Black, Pink, Corlourful",
    category: "cloths",
    store_name: "Lady's under wear"

    },



    {

    user_id:"7",
    title:"Brassiere (one set)",
                made_by_country: "China",
    price:15000,
    size:"70/32A, 75/34A, 36/80A",
    color: "Black,Blue, Peach, light pink, deep pink, yellow",
    category: "cloths",
    store_name: "Lady's under wear"

    },


    {

    user_id:"7",
    title:"Brassiere",
    made_by_country: "China",
    price:11500,
    size:"70/A32, 70B/32, 75/34A, 75/34B, 36/80A",
    color: "Black,Blue, Peach, light pink, deep pink, yellow",
    category: "cloths",
    store_name: "Lady's under wear"

    },


    {

    user_id:"7",
    title:"Brassiere (one set)",
    made_by_country: "China",
    price:13500,
    size:"70/A32, 70B/32, 75/34A, 75/34B, 36/80A",
    color: "Yellow, Pink, Light green, Dark green, Blue",
    category: "cloths",
    store_name: "Lady's under wear"

    },




])







user = User.create([
  # seller
 {user_type_id:"1", has_store:"Yes", name:"htoomyatag1",company_name:"MiMiBerry", phone:"09795545748", email: "htoomyatag1.webdev@gmail.com", password: "privatehma", password_confirmation: "privatehma"},
  {user_type_id:"1", has_store:"Yes", name:"htoomyatag2",company_name:"OverDoze", phone:"09795545748", email: "htoomyatag2.webdev@gmail.com", password: "privatehma", password_confirmation: "privatehma"},
  {user_type_id:"1", has_store:"Yes", name:"theldarlykhin1",company_name:"5000Kyats", phone:"0930210743",email: "theldarlykhin1.webdev@gmail.com", password: "privatethel", password_confirmation: "privatethel"},
  {user_type_id:"1", has_store:"Yes", name:"theldarlykhin2",company_name:"S3 fashion", phone:"0930210743",email: "theldarlykhin2.webdev@gmail.com", password: "privatethel", password_confirmation: "privatethel"},
  {user_type_id:"1", has_store:"Yes", name:"tracy1",company_name:"Lady's foot wear", phone:"095016213",email: "tracy1@gmail.com", password: "privatetracy", password_confirmation: "privatetracy"},
  {user_type_id:"1", has_store:"Yes", name:"tracy2",company_name:"Luggage", phone:"095016213",email: "tracy2@gmail.com", password: "privatetracy", password_confirmation: "privatetracy"},
  {user_type_id:"1", has_store:"Yes", name:"tracy3",company_name:"Lady's under wear", phone:"095016213",email: "tracy3@gmail.com", password: "privatetracy", password_confirmation: "privatetracy"},

  # buyer


  # {user_type_id:"2",name: "htoo", email: "htoomyatag@gmail.com", password: "privatehma", password_confirmation: "privatehma"},
  # {user_type_id:"2",name: "thel", email: "theldarlykhin@gmail.com", password: "privatethel", password_confirmation: "privatethel"},
  {user_type_id:"2",name: "arphan", email: "arphan@gmail.com", password: "privateafan", password_confirmation: "privateafan"},
  {user_type_id:"2",name: "guest", email: "guestguest@gmail.com", password: "privateafan", password_confirmation: "privateafan"}
 


])




store = Store.create([

{

  store_name:"MiMiBerry",
  store_address:"Thamile 7street, Building 606, 6h floor",
  store_contact:"09795545748",
  user_id:"1",
  seller_name:"htoomyatag1"

},


{

  store_name:"OverDoze",
  store_address:"Thamile 7street, Building 606, 6h floor",
  store_contact:"09795545748",
  user_id:"2",
  seller_name:"htoomyatag2"

},



{

  store_name:"5000Kyats",
  store_address:"Thamile 7street, Building 606, 6h floor",
  store_contact:"09795545748",
  user_id:"3",
  seller_name:"theldarlykhin1"

},



{

  store_name:"S3 fashion",
  store_address:"Thamile 7street, Building 606, 6h floor",
  store_contact:"09795545748",
  user_id:"4",
  seller_name:"theldarlykhin2"

},



{

  store_name:"Lady's foot wear",
  store_contact:"095016213",
  user_id:"5",
  seller_name:"tracy1"

},



{

  store_name:"Luggage",
  store_contact:"095016213",
  user_id:"6",
  seller_name:"tracy2"

},

{

  store_name:"Lady's under wear",
  store_contact:"095016213",
  user_id:"7",
  seller_name:"tracy3"

},




])

