require 'test_helper'

class HomeApplianceTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
