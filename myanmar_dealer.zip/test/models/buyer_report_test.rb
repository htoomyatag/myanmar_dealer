require 'test_helper'

class BuyerReportTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
