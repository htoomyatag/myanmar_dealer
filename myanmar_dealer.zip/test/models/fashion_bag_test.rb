require 'test_helper'

class FashionBagTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
