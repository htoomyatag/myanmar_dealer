require 'test_helper'

class TrainingAndSchoolTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
