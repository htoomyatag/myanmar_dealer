require 'test_helper'

class BeautyEquipmentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
