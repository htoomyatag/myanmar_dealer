require 'test_helper'

class TelephoneAccessoryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
