require 'test_helper'

class FashionAccessoryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
