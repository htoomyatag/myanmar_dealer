require 'test_helper'

class MakeupAndSkincareTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
