require 'test_helper'

class UserTypeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
