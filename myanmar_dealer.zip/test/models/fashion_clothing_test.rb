require 'test_helper'

class FashionClothingTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
