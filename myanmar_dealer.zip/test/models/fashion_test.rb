require 'test_helper'

class FashionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
