require 'test_helper'

class ElectricalEquipmentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
