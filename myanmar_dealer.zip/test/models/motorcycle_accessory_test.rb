require 'test_helper'

class MotorcycleAccessoryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
