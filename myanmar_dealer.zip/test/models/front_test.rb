require 'test_helper'

class FrontTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
